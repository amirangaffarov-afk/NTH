import { Link } from "@tanstack/react-router";
import { Logo } from "@/components/logo";
import { COMPANY, PHONES } from "@/lib/company";
import { telHref } from "@/lib/format";
import { useI18n } from "src/lib/i18n";

export function SiteFooter() {
  const { t } = useI18n();
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-line bg-surface">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-3">
            <Logo className="size-10" />
            <div>
              <p className="font-display text-lg uppercase tracking-wide">{t.brand.name}</p>
              <p className="text-sm text-muted">{t.brand.slogan}</p>
            </div>
          </div>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-muted">{t.meta.description}</p>
        </div>
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-subtle">{t.nav.products}</p>
          <ul className="mt-3 space-y-2 text-sm">
            <li>
              <Link to="/mahsulotlar" className="text-muted hover:text-fg">
                {t.directions.asphalt.title}
              </Link>
            </li>
            <li>
              <Link to="/xizmatlar" className="text-muted hover:text-fg">
                {t.nav.services}
              </Link>
            </li>
            <li>
              <Link to="/vakansiyalar" className="text-muted hover:text-fg">
                {t.nav.jobs}
              </Link>
            </li>
            <li>
              <Link to="/aloqa" className="text-muted hover:text-fg">
                {t.nav.contact}
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-subtle">{t.contactPage.phonesTitle}</p>
          <ul className="mt-3 space-y-2 text-sm">
            {PHONES.main.map((p) => (
              <li key={p.digits}>
                <a href={telHref(p.digits)} className="text-fg hover:text-primary">
                  {p.label}
                </a>
              </li>
            ))}
            <li>
              <a href={COMPANY.telegram} className="text-muted hover:text-fg" target="_blank" rel="noreferrer">
                t.me/nurli_tulqin_holding
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-4 text-xs text-subtle sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <span>
            © {year} {COMPANY.name}. {t.footer.rights}
          </span>
          <span>{t.footer.made}</span>
        </div>
      </div>
    </footer>
  );
}
