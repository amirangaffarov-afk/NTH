import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useI18n } from "src/lib/i18n";

const LEADS_KEY = "nth-leads";

export function ContactForm({ initialProduct = "asphalt" }: { initialProduct?: string }) {
  const { t } = useI18n();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [product, setProduct] = useState(initialProduct);
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const digits = phone.replace(/\D/g, "");
    if (!name.trim() || digits.length < 9) {
      toast.error(t.contactPage.formError);
      return;
    }
    const lead = {
      name: name.trim(),
      phone: phone.trim(),
      product,
      message: message.trim(),
      at: new Date().toISOString(),
    };
    try {
      const prev = JSON.parse(localStorage.getItem(LEADS_KEY) || "[]") as unknown[];
      localStorage.setItem(LEADS_KEY, JSON.stringify([lead, ...prev].slice(0, 20)));
    } catch {
      /* ignore quota */
    }
    setSent(true);
    toast.success(t.contactPage.formSent);
  }

  if (sent) {
    return (
      <div className="rounded-xl border border-line bg-surface p-6 sm:p-8">
        <p className="font-display text-2xl uppercase text-fg">{t.contactPage.formSent}</p>
        <p className="mt-2 text-sm text-muted">{t.cta.text}</p>
      </div>
    );
  }

  const opts = t.contactPage.productOpts;

  return (
    <form onSubmit={onSubmit} className="rounded-xl border border-line bg-surface p-5 sm:p-8">
      <div className="grid gap-4">
        <div className="grid gap-1.5">
          <Label htmlFor="name">{t.contactPage.formName}</Label>
          <Input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t.form.namePh}
            autoComplete="name"
          />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="phone">{t.contactPage.formPhone}</Label>
          <Input
            id="phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder={t.form.phonePh}
            inputMode="tel"
            autoComplete="tel"
          />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="product">{t.contactPage.formProduct}</Label>
          <select
            id="product"
            value={product}
            onChange={(e) => setProduct(e.target.value)}
            className="flex h-11 w-full rounded-md border border-line bg-surface px-3 text-sm text-fg focus-visible:border-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40"
          >
            {Object.entries(opts).map(([key, label]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="message">{t.contactPage.formMessage}</Label>
          <Textarea
            id="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder={t.form.messagePh}
          />
        </div>
        <Button type="submit" size="lg" className="w-full sm:w-auto">
          {t.contactPage.formSend}
        </Button>
      </div>
    </form>
  );
}
