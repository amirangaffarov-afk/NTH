import { Link } from "@tanstack/react-router";
import { Calculator, MessageCircle, Phone } from "lucide-react";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { COMPANY, PHONES } from "@/lib/company";
import { telHref } from "@/lib/format";
import { useI18n } from "src/lib/i18n";

export function SiteShell({ children }: { children: React.ReactNode }) {
  const { t } = useI18n();

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <SiteHeader />
      <main className="flex-1 pb-20 lg:pb-0">{children}</main>
      <SiteFooter />
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-bg/95 backdrop-blur-md lg:hidden">
        <div className="grid grid-cols-3">
          <a
            href={telHref(PHONES.main[0].digits)}
            className="flex h-14 flex-col items-center justify-center gap-0.5 text-[0.7rem] font-medium text-fg"
          >
            <Phone className="size-4" />
            {t.float.call}
          </a>
          <a
            href={COMPANY.telegram}
            target="_blank"
            rel="noreferrer"
            className="flex h-14 flex-col items-center justify-center gap-0.5 text-[0.7rem] font-medium text-fg"
          >
            <MessageCircle className="size-4" />
            {t.float.chat}
          </a>
          <Link
            to="/"
            hash="hisob"
            className="flex h-14 flex-col items-center justify-center gap-0.5 bg-primary text-[0.7rem] font-medium text-primary-fg"
          >
            <Calculator className="size-4" />
            {t.float.calc}
          </Link>
        </div>
      </div>
    </div>
  );
}

export function PageHero({
  kicker,
  title,
  lead,
}: {
  kicker: string;
  title: string;
  lead: string;
}) {
  return (
    <section className="border-b border-line bg-surface pt-24 sm:pt-28">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">{kicker}</p>
        <h1 className="mt-3 max-w-3xl font-display text-section uppercase">{title}</h1>
        <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted">{lead}</p>
      </div>
    </section>
  );
}
