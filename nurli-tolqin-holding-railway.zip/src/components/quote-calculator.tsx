import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PRICES } from "@/lib/company";
import { formatNum, formatSom } from "@/lib/format";
import { useI18n } from "src/lib/i18n";
import { cn } from "@/lib/utils";

type Kind = "asphalt" | "concrete" | "slab";

export function QuoteCalculator({ compact = false }: { compact?: boolean }) {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const [kind, setKind] = useState<Kind>("asphalt");
  const [length, setLength] = useState("20");
  const [width, setWidth] = useState("4");
  const [thickness, setThickness] = useState("5");

  const L = Number(length) || 0;
  const W = Number(width) || 0;
  const Tcm = Number(thickness) || 0;
  const area = L * W;
  const depthM = Tcm / 100;

  const result = useMemo(() => {
    if (area <= 0) return null;
    if (kind === "asphalt") {
      if (depthM <= 0) return null;
      const volume = area * depthM;
      const tons = volume * PRICES.asphaltDensity;
      const price = tons * PRICES.asphaltPerTon;
      return { area, volume, tons, price };
    }
    if (kind === "concrete") {
      if (depthM <= 0) return null;
      const volume = area * depthM;
      return { area, volume, tons: 0, price: volume * PRICES.concretePerM3 };
    }
    const meters = Math.max(L, W) || area;
    return { area, volume: 0, tons: 0, price: meters * PRICES.slabPerM };
  }, [area, depthM, kind, L, W]);

  const tabs: { id: Kind; label: string }[] = [
    { id: "asphalt", label: t.calc.asphalt },
    { id: "concrete", label: t.calc.concrete },
    { id: "slab", label: t.calc.slab },
  ];

  return (
    <div className={cn("rounded-xl border border-line bg-surface p-5 sm:p-8", compact && "p-4")}>
      <div className="flex flex-wrap gap-2">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setKind(tab.id)}
            className={cn(
              "h-10 rounded-md px-4 text-sm font-medium",
              kind === tab.id ? "bg-primary text-primary-fg" : "bg-surface-2 text-muted",
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <Field label={t.calc.length} value={length} onChange={setLength} />
        <Field label={t.calc.width} value={width} onChange={setWidth} />
        {kind !== "slab" ? (
          <Field
            label={kind === "asphalt" ? t.calc.thickness : t.calc.height}
            value={thickness}
            onChange={setThickness}
          />
        ) : (
          <div className="hidden sm:block" />
        )}
      </div>

      <div className="mt-6 rounded-lg bg-bg p-4 sm:p-5">
        {result ? (
          <dl className="grid gap-3 sm:grid-cols-2">
            <Stat label={t.calc.area} value={`${formatNum(result.area, 1)} m²`} />
            {kind !== "slab" ? (
              <Stat label={t.calc.volume} value={`${formatNum(result.volume, 2)} m³`} />
            ) : null}
            {kind === "asphalt" ? (
              <Stat label={t.calc.mass} value={`${formatNum(result.tons, 1)} t`} />
            ) : null}
            <Stat
              label={t.calc.estimate}
              value={`${t.calc.from} ${formatSom(result.price, lang)}`}
              accent
            />
          </dl>
        ) : (
          <p className="text-sm text-muted">{t.calc.resultEmpty}</p>
        )}
      </div>

      <p className="mt-4 text-xs leading-relaxed text-subtle">{t.calc.note}</p>

      <Button
        className="mt-5 w-full sm:w-auto"
        onClick={() =>
          navigate({
            to: "/aloqa",
            search: { product: kind },
          })
        }
      >
        {t.calc.submit}
      </Button>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="grid gap-1.5">
      <Label>{label}</Label>
      <Input
        inputMode="decimal"
        value={value}
        onChange={(e) => onChange(e.target.value.replace(",", "."))}
      />
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div>
      <dt className="text-xs uppercase tracking-[0.14em] text-subtle">{label}</dt>
      <dd
        className={cn(
          "mt-1 font-display text-xl uppercase tabular-nums",
          accent ? "text-primary" : "text-fg",
        )}
      >
        {value}
      </dd>
    </div>
  );
}
