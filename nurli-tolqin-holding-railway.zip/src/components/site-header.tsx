import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, Phone, X } from "lucide-react";
import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { COMPANY, PHONES } from "@/lib/company";
import { useI18n } from "src/lib/i18n";
import { cn } from "@/lib/utils";
import { telHref } from "@/lib/format";

const LINKS = [
  { to: "/kompaniya", key: "company" },
  { to: "/mahsulotlar", key: "products" },
  { to: "/xizmatlar", key: "services" },
  { to: "/loyihalar", key: "projects" },
  { to: "/vakansiyalar", key: "jobs" },
  { to: "/aloqa", key: "contact" },
] as const;

export function SiteHeader() {
  const { t, lang, setLang } = useI18n();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-[background-color,border-color,backdrop-filter] duration-[var(--motion-fast)]",
        scrolled || open
          ? "border-b border-line bg-bg/92 backdrop-blur-md"
          : "border-b border-transparent bg-transparent",
      )}
    >
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:h-[4.25rem] sm:px-6">
        <Link to="/" className="flex min-w-0 items-center gap-2.5" onClick={() => setOpen(false)}>
          <Logo className="size-9 sm:size-10" />
          <span className="min-w-0">
            <span className="block truncate font-display text-sm font-semibold uppercase tracking-wide text-fg sm:text-base">
              {t.brand.name}
            </span>
            <span className="hidden text-[0.7rem] uppercase tracking-[0.18em] text-muted sm:block">
              {t.brand.holding}
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {LINKS.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="rounded-md px-3 py-2 text-sm text-muted transition-colors duration-[var(--motion-quick)] hover:bg-surface-2 hover:text-fg"
              activeProps={{ className: "bg-surface-2 text-fg" }}
            >
              {t.nav[item.key]}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <div className="flex overflow-hidden rounded-md border border-line text-xs font-semibold">
            <button
              type="button"
              onClick={() => setLang("uz")}
              className={cn(
                "h-9 px-2.5",
                lang === "uz" ? "bg-surface-2 text-fg" : "text-muted",
              )}
              aria-pressed={lang === "uz"}
            >
              UZ
            </button>
            <button
              type="button"
              onClick={() => setLang("ru")}
              className={cn(
                "h-9 px-2.5",
                lang === "ru" ? "bg-surface-2 text-fg" : "text-muted",
              )}
              aria-pressed={lang === "ru"}
            >
              RU
            </button>
          </div>
          <Button asChild variant="outline" size="sm" className="hidden sm:inline-flex">
            <a href={telHref(PHONES.main[0].digits)}>
              <Phone />
              {PHONES.main[0].label}
            </a>
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="lg:hidden"
            aria-label={open ? t.nav.close : t.nav.menu}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X /> : <Menu />}
          </Button>
        </div>
      </div>

      {open ? (
        <div className="border-t border-line bg-bg lg:hidden">
          <nav className="mx-auto flex max-w-6xl flex-col px-4 py-4" aria-label="Mobile">
            {LINKS.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="border-b border-line py-4 font-display text-xl uppercase tracking-wide text-fg"
              >
                {t.nav[item.key]}
              </Link>
            ))}
            <a
              href={COMPANY.telegram}
              className="py-4 text-sm text-muted"
              target="_blank"
              rel="noreferrer"
            >
              Telegram
            </a>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
