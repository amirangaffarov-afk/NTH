import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 64 64"
      className={cn("shrink-0", className)}
      aria-hidden="true"
    >
      <circle cx="32" cy="32" r="31" fill="#0b1c33" />
      <circle cx="32" cy="32" r="27.5" fill="#f4f7fb" />
      <circle cx="32" cy="32" r="27.5" fill="none" stroke="#1a4f96" strokeWidth="1.6" />
      <path
        fill="#1e5aa8"
        d="M16.8 44.8V19.6h6.1v15.2L32.2 19.6H39v25.2h-6.1V28.8L23.4 44.8H16.8z"
      />
      <path fill="#2f74c0" d="M40.2 19.6H53.4v5.4H47.2v19.8h-7V19.6z" />
      <rect x="19.2" y="23.2" width="3.2" height="3.2" fill="#f4f7fb" />
    </svg>
  );
}
