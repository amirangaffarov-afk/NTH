import { Link } from "@tanstack/react-router";
import { Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { COMPANY, PHONES } from "@/lib/company";
import { telHref } from "@/lib/format";
import { useI18n } from "src/lib/i18n";
import { cn } from "@/lib/utils";

export function Section({
  id,
  children,
  className,
  innerClassName,
}: {
  id?: string;
  children: React.ReactNode;
  className?: string;
  innerClassName?: string;
}) {
  return (
    <section id={id} className={cn("scroll-mt-24 border-b border-line", className)}>
      <div className={cn("mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20", innerClassName)}>
        {children}
      </div>
    </section>
  );
}

export function Kicker({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-xs font-semibold uppercase tracking-kicker text-primary">{children}</p>
  );
}

export function SectionTitle({ children }: { children: React.ReactNode }) {
  return <h2 className="mt-3 max-w-3xl font-display text-section uppercase">{children}</h2>;
}

export function Lead({ children }: { children: React.ReactNode }) {
  return <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted">{children}</p>;
}

export function Frame({
  src,
  alt,
  className,
  priority = false,
}: {
  src: string;
  alt: string;
  className?: string;
  priority?: boolean;
}) {
  return (
    <img
      src={src}
      alt={alt}
      className={cn("size-full object-cover", className)}
      loading={priority ? "eager" : "lazy"}
      fetchPriority={priority ? "high" : "auto"}
      decoding="async"
    />
  );
}

export function CtaBand() {
  const { t } = useI18n();
  return (
    <section className="border-b border-line bg-surface">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-16 sm:px-6 sm:py-20 md:flex-row md:items-end md:justify-between">
        <div className="max-w-xl">
          <h2 className="font-display text-section uppercase">{t.cta.title}</h2>
          <p className="mt-3 text-base leading-relaxed text-muted">{t.cta.text}</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <Button asChild size="lg">
            <a href={COMPANY.telegram} target="_blank" rel="noreferrer">
              {t.cta.telegram}
            </a>
          </Button>
          <Button asChild size="lg" variant="outline">
            <a href={telHref(PHONES.main[0].digits)}>
              <Phone />
              {t.cta.call}
            </a>
          </Button>
          <Button asChild size="lg" variant="ghost">
            <Link to="/aloqa">{t.nav.contact}</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
