function groupThousands(intPart: string): string {
  return intPart.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

export function formatSom(value: number, lang: "uz" | "ru"): string {
  const rounded = Math.round(value);
  const formatted = groupThousands(String(Math.abs(rounded)));
  const signed = rounded < 0 ? `-${formatted}` : formatted;
  return lang === "ru" ? `${signed} сум` : `${signed} so‘m`;
}

export function formatNum(value: number, digits = 1): string {
  if (!Number.isFinite(value)) return "0";
  const factor = 10 ** digits;
  const rounded = Math.round(value * factor) / factor;
  const [intPart, frac = ""] = rounded.toFixed(digits).split(".");
  const grouped = groupThousands(intPart.startsWith("-") ? intPart.slice(1) : intPart);
  const signed = intPart.startsWith("-") ? `-${grouped}` : grouped;
  const trimmedFrac = frac.replace(/0+$/, "");
  return trimmedFrac ? `${signed},${trimmedFrac}` : signed;
}

export function telHref(phone: string): string {
  return `tel:+${phone.replace(/\D/g, "")}`;
}
