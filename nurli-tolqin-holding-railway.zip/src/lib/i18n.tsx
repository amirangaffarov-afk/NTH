import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

export type Lang = "uz" | "ru";

const uz = {
  meta: {
    title: "Nurli To‘lqin Holding — asfalt, beton va yo‘l qurilishi",
    description:
      "Jizzax, Sirdaryo va Toshkent viloyatlarida asfalt, tayyor beton, inert materiallar va maxsus texnika. Sifatni qadrlaydiganlar uchun.",
  },
  nav: {
    home: "Bosh sahifa",
    company: "Kompaniya",
    products: "Mahsulotlar",
    services: "Xizmatlar",
    projects: "Loyihalar",
    jobs: "Vakansiyalar",
    contact: "Aloqa",
    menu: "Menyu",
    close: "Yopish",
  },
  brand: {
    name: "Nurli To‘lqin",
    holding: "Holding",
    slogan: "Sifatni qadrlaydiganlar uchun",
  },
  hero: {
    kicker: "Jizzax · Sirdaryo · Toshkent",
    title: "Sifatli yo‘llar sizdan boshlanadi",
    lead: "Asfalt va tayyor beton, daryo-tog‘ inert materiallari, sement va maxsus texnika — bitta holding ostida, laboratoriya nazorati bilan.",
    ctaCalc: "Narxni hisoblash",
    ctaCall: "Qo‘ng‘iroq qilish",
    ctaProducts: "Mahsulotlar",
  },
  stats: {
    plants: "asfalt zavodi",
    regions: "viloyatda ishlab chiqarish",
    lines: "mahsulot yo‘nalishi",
    lab: "laboratoriya nazorati",
    capacity: "soatiga quvvat",
    staff: "ishchi-xizmatchi",
    fleet: "maxsus texnika",
  },
  directions: {
    kicker: "Yo‘nalishlar",
    title: "Holding nima ishlab chiqaradi",
    lead: "Qurilish zanjirining asosiy bo‘g‘inlari — xomashyodan yo‘l qatlamigacha — o‘z quvvatlarimizda.",
    asphalt: {
      title: "Asfalt mahsulotlari",
      text: "Issiq asfaltbeton aralashmasi, yetkazib berish, yotqizish va bosish. Tarkibida Rossiya bitumi, mineral kukun va laboratoriya nazorati.",
    },
    concrete: {
      title: "Tayyor beton",
      text: "M400 gacha markali tayyor beton, beton plitalar va Ultra Beton qurilish buyumlari — kerakli o‘lchamda.",
    },
    aggregate: {
      title: "Daryo va tog‘ materiallari",
      text: "Sheben, shag‘al va qurilish qumlari. New Nerud liniyasi — karer va daryo inert mahsulotlari.",
    },
    logistics: {
      title: "Texnika va logistika",
      text: "Sementovoz, samosval, asfalt yotqizgich, katok, greyder, buldozer va boshqa mexanizmlar xizmati.",
    },
  },
  why: {
    kicker: "Nega biz",
    title: "Sifat — zavoddan yo‘lgacha",
    lead: "Toshkent, Sirdaryo va Jizzax viloyatlarida yagona yondashuv: xomashyo, laboratoriya va yotqizish brigadasi bir tizimda.",
    items: [
      {
        title: "Italiya va Germaniya texnologiyasi",
        text: "Zamonaviy asfalt-beton uzellari, standartlarga javob beruvchi ishlab chiqarish tsikli.",
      },
      {
        title: "Rossiya bitumi",
        text: "Asfalt tarkibida barqaror bitum — qatlam yorilmasin, yo‘l uzoq xizmat qilsin.",
      },
      {
        title: "Laboratoriya nazorati",
        text: "Har bir partiya mineral kukun va laborator tekshiruvdan o‘tadi.",
      },
      {
        title: "O‘z brigadasi va texnikasi",
        text: "Yetkazib berish, yotqizish va bosish — ishchi kuchi va mexanizmlar o‘zimizda.",
      },
    ],
  },
  plants: {
    kicker: "Geografiya",
    title: "Uch viloyatda ishlab chiqarish",
    jizzax: {
      title: "Jizzax — bosh quvvat",
      text: "Jizzax shahri, A-sanoat hududi. Mo‘ljal: «DEYA» shirinlik zavodi ro‘parasi, 8-avtobus oxirgi bekati.",
    },
    sirdaryo: {
      title: "Sirdaryo filiali",
      text: "Sirdaryo viloyatidagi asfalt zavodi. Yetkazib berish, yotqizish va bosish to‘liq tsikl.",
    },
    toshkent: {
      title: "Toshkent viloyati filiali",
      text: "Toshkent viloyatida sifatli asfalt mahsuloti va yo‘l qurilishi xizmati.",
    },
  },
  calc: {
    kicker: "Tezkor hisob",
    title: "Buyurtma hajmini hisoblang",
    lead: "Narxlar taxminiy, «dan» boshlanadi. Aniq smeta uchun mutaxassis joyni ko‘zdan kechiradi.",
    asphalt: "Asfalt",
    concrete: "Tayyor beton",
    slab: "Beton plita",
    length: "Uzunlik, m",
    width: "Kenglik, m",
    thickness: "Qalinlik, sm",
    height: "Qalinlik, sm",
    area: "Maydon",
    volume: "Hajm",
    mass: "Og‘irlik",
    estimate: "Taxminiy summa",
    from: "dan",
    perTon: "so‘m / tonna",
    perM3: "so‘m / m³",
    perM: "so‘m / m",
    submit: "Buyurtma qoldirish",
    note: "Asfalt og‘irligi 2,35 t/m³ qabul qilingan. Yakuniy narx masofa, asos qatlami va mavsumga qarab o‘zgaradi.",
    resultEmpty: "O‘lchamlarni kiriting — hisob avtomatik chiqadi.",
  },
  projects: {
    kicker: "Loyihalar",
    title: "Yo‘l — odamlar uchun",
    all: "Barchasi",
    road: "Ichki yo‘llar",
    city: "Shahar",
    yard: "Hovli",
    viewAll: "Barcha loyihalar",
    items: [
      {
        id: "forish",
        tag: "road",
        title: "Forish, Safar ota qishlog‘i",
        text: "UCHMA MFY ichki yo‘llari. 407 xonadon uchun qulay va xavfsiz harakat.",
      },
      {
        id: "rashidov",
        tag: "city",
        title: "Jizzax: Rashidov — Narimanov",
        text: "Ikki ko‘chani bog‘lovchi yangi yo‘l — shahar infratuzilmasi.",
      },
      {
        id: "baxmal",
        tag: "road",
        title: "Baxmal, Madaniyat MFY",
        text: "Open Budget doirasida ichki ko‘chalarni asfaltlash.",
      },
      {
        id: "yard",
        tag: "yard",
        title: "Uy-hovli asfalti",
        text: "Ko‘zdan kechirish, o‘lchov, tijorat taklifi va bir kunda yurishga tayyor qatlam.",
      },
    ],
  },
  subs: {
    kicker: "Holding tarkibi",
    title: "NTH, Ultra Beton, New Nerud",
    nth: "Bosh holding — asfalt zavodlari, yo‘l qurilishi va maxsus texnika parki.",
    ultra: "Yuqori markali beton, plitalar va bog‘-uzumzor tayanchlari. M400, kerakli o‘lcham.",
    nerud: "Daryo va tog‘ inert materiallari: sheben, shag‘al, qurilish qumi.",
  },
  cta: {
    title: "Yo‘lingizni bugun hisoblaymiz",
    text: "Mutaxassis bepul ko‘zdan kechiradi. Telegram yoki qo‘ng‘iroq — qaysi biri qulay bo‘lsa.",
    telegram: "Telegram",
    call: "Qo‘ng‘iroq",
  },
  aboutPage: {
    kicker: "Kompaniya",
    title: "Qurilishni ushlab turadigan holding",
    lead: "«Nurli To‘lqin» Holding Jizzaxda joylashgan, Toshkent va Sirdaryo viloyatlarida filiallari bor ishlab chiqarish guruhi. Biz yo‘lni nafaqat yotqizamiz — asfaltni o‘zimiz ishlab chiqaramiz.",
    storyTitle: "Zavod, laboratoriya, brigada",
    story:
      "Ko‘pchilik asfaltni faqat qoplama deb biladi. Biz uni uzoq yillik investitsiya deb hisoblaymiz. Shu bois aralashma tarkibi, bitum sifati va yotqizish texnologiyasi bitta tizimda nazorat qilinadi. Issiq asfalt yetkaziladi, yotqiziladi va bosiladi — ishchi kuchi ham, mexanizmlar ham o‘zimizda.",
    valuesTitle: "Ish tamoyillari",
    values: [
      { title: "Sifat", text: "Laboratoriya, mineral kukun, barqaror bitum." },
      { title: "Shaffoflik", text: "O‘lchov, smeta, muddat — oldindan." },
      { title: "Tezlik", text: "To‘g‘ri yotqizilgan asfalt 1 kunda yurishga tayyor." },
      { title: "Qamrov", text: "Viloyat yo‘llari, mahalla ko‘chalari, hovlilar." },
    ],
    factsTitle: "Raqamlarda",
    facts: [
      { n: "2,5 ga", text: "Jizzaxdagi ishlab chiqarish maydoni." },
      { n: "250 t/soat", text: "Zamonaviy asfalt zavodi quvvati." },
      { n: "460 ming t", text: "Yillik asfalt-beton ishlab chiqarish imkoniyati." },
      { n: "450+", text: "Ishchi-xizmatchi — yotoqxona, oshxona, maxsus kiyim." },
      { n: "200+", text: "Maxsus texnika, samosval va yuklagichlar parki." },
      { n: "6", text: "Tosh maydalash korxonasi Sharof Rashidov va G‘allaorolda." },
    ],
  },
  productsPage: {
    kicker: "Mahsulotlar",
    title: "Zavoddan chiqadigan narsa",
    lead: "Narxlar Prom.uz katalogidagi boshlang‘ich qiymatlar. Hajm, masofa va markaga qarab aniq smeta beriladi.",
    asphaltTitle: "Tayyor asfalt mahsulotlari",
    asphaltText:
      "Issiq asfaltbeton aralashmasi. Tarkibida Rossiya bitumi, qo‘shimcha mineral kukun. Yetkazib berish, yotqizish va bosish alohida yoki paket holda.",
    asphaltPrice: "480 000 so‘m / t dan",
    concreteTitle: "Tayyor beton",
    concreteText:
      "Qurilish maydonchasiga yetkaziladigan beton aralashmasi. Ultra Beton liniyasida M400 gacha marka.",
    concretePrice: "470 000 so‘m / m³ dan",
    slabTitle: "Beton plitalar",
    slabText: "Yopma va yo‘l plitalari. Kerakli o‘lchamda buyurtma qilinadi.",
    slabPrice: "230 000 so‘m / m dan",
    cementTitle: "Sement — qoplik va naval",
    cementText: "Optom sement, sementovoz orqali yetkazib berish. Qoplik va naval rejimida.",
    aggregateTitle: "Inert materiallar",
    aggregateText: "Sheben, shag‘al, qum — daryo va tog‘ karerlaridan. Asos qatlami va beton uchun.",
    ultraTitle: "Ultra Beton buyumlari",
    ultraText:
      "Uzumzor va intensiv bog‘lar uchun 10×10 sm tayanchlar, ichida BP-1400 sim. Beton — M400.",
  },
  servicesPage: {
    kicker: "Xizmatlar",
    title: "Yotqizish, bosish, mexanizmlar",
    lead: "Mahsulotni nafaqat sotamiz — yo‘lni tayyorlab, asfaltni yotqizib, katok bilan bosamiz.",
    processTitle: "Hovli va yo‘l — 4 bosqich",
    steps: [
      {
        n: "01",
        title: "Joyni ko‘zdan kechirish",
        text: "Mutaxassis maydon, qiyalik va mavjud qatlamni o‘rganadi. Xizmat bepul.",
      },
      {
        n: "02",
        title: "O‘lchov va hisob",
        text: "Kvadrat metr, tuproq holati, sheben ehtiyoji aniqlanadi.",
      },
      {
        n: "03",
        title: "Tijorat taklifi",
        text: "Narx va ish muddati yozma shaklda. Hammasi shaffof.",
      },
      {
        n: "04",
        title: "Ish boshlanishi",
        text: "Toza, tekis, shag‘al, issiq asfalt. To‘g‘ri yotqizilgan qatlam 1 kunda yurishga tayyor.",
      },
    ],
    fleetTitle: "Maxsus texnika parki",
    fleetLead: "Asfalt yotqizgichdan gudronatorgacha — buyurtma asosida ijaraga ham beriladi.",
  },
  jobsPage: {
    kicker: "Vakansiyalar",
    title: "Jamoaga qo‘shiling",
    lead: "Zamonaviy ofis, zavod va yo‘l brigadalari. Batafsil e’lonlar @nthvacancy kanalida.",
    apply: "Murojaat",
    channel: "Vakansiya kanali",
    items: [
      {
        id: "secretary",
        title: "Kotiba",
        place: "Bosh ofis",
        text: "Kompyuterda ishlay olish, tartibli va mas’uliyatli. Yosh: 30–40. Yaxshi oylik kafolatlanadi.",
      },
      {
        id: "paver",
        title: "Asfalt yotqizgich operatori",
        place: "Jizzax / Sirdaryo",
        text: "Vögele yoki o‘xshash texnikada tajriba. Yo‘l qurilishi brigadasida ish.",
      },
      {
        id: "driver",
        title: "Sementovoz / samosval haydovchisi",
        place: "Logistika",
        text: "CE toifasi, sanoat tashish tajribasi. Park yangilanadi, marshrutlar viloyatlararo.",
      },
      {
        id: "lab",
        title: "Laborant",
        place: "Asfalt zavodi",
        text: "Aralashma namunalari, mineral kukun va bitum nazorati. Profil ma’lumoti afzal.",
      },
      {
        id: "foreman",
        title: "Yo‘l qurilishi prorabi",
        place: "Obyektlar",
        text: "Asfaltga tayyorlash va yotqizishni boshqarish, smeta va sifat nazorati.",
      },
    ],
  },
  contactPage: {
    kicker: "Aloqa",
    title: "Buyurtma va maslahat",
    lead: "Telefon, Telegram yoki forma — qaysi yo‘l qulay bo‘lsa, o‘sha orqali yozing. Ish vaqtida javob beramiz.",
    formName: "Ism",
    formPhone: "Telefon",
    formProduct: "Mahsulot / xizmat",
    formMessage: "Izoh",
    formSend: "Yuborish",
    formSent: "So‘rov qabul qilindi. Tez orada bog‘lanamiz.",
    formError: "Ism va telefonni to‘ldiring.",
    addressTitle: "Bosh ofis / zavod",
    address:
      "Jizzax shahri, A-sanoat hududi. Mo‘ljal: «DEYA» shirinlik zavodi ro‘parasi, 8-avtobus oxirgi bekati.",
    phonesTitle: "Telefonlar",
    socialsTitle: "Ijtimoiy tarmoqlar",
    plantsTitle: "Zavodlar",
    map: "Xaritada ochish",
    productOpts: {
      asphalt: "Asfalt",
      concrete: "Tayyor beton",
      slab: "Beton plita",
      cement: "Sement",
      machinery: "Texnika xizmati",
      aggregate: "Inert materiallar",
      ultra: "Ultra Beton",
      other: "Boshqa",
    },
  },
  form: {
    namePh: "Ismingiz",
    phonePh: "+998 ·· ··· ·· ··",
    messagePh: "Maydon, manzil, muddat…",
  },
  footer: {
    rights: "Barcha huquqlar himoyalangan.",
    made: "Jizzax, O‘zbekiston",
  },
  notFound: {
    title: "Sahifa topilmadi",
    text: "Bu manzil mavjud emas yoki ko‘chirilgan.",
    home: "Bosh sahifa",
  },
  machinery: {
    paver: "Asfalt yotqizgich",
    pneumatic: "Pnevmatik katok",
    roller95: "Katok",
    roller85: "Katok",
    roller27: "Katok",
    vibro: "Vibrokatok",
    grader: "Greyder",
    trailer: "Treyler",
    miller: "Freza",
    bulldozer: "Buldozer",
    bitumen: "Bitumovoz",
    manipulator: "Manipulyator",
    water20: "Suv tashigich",
    water8: "Suv tashigich",
    distributor: "Gudronator",
    cementTruck: "Sementovoz",
    dump: "Samosval",
  },
  float: {
    call: "Qo‘ng‘iroq",
    chat: "Chat",
    calc: "Hisob",
  },
};

const ru: typeof uz = {
  meta: {
    title: "Nurli To‘lqin Holding — асфальт, бетон и дороги",
    description:
      "Асфальт, товарный бетон, инертные материалы и спецтехника в Джизаке, Сырдарье и Ташкентской области.",
  },
  nav: {
    home: "Главная",
    company: "Компания",
    products: "Продукция",
    services: "Услуги",
    projects: "Проекты",
    jobs: "Вакансии",
    contact: "Контакты",
    menu: "Меню",
    close: "Закрыть",
  },
  brand: {
    name: "Nurli To‘lqin",
    holding: "Holding",
    slogan: "Для тех, кто ценит качество",
  },
  hero: {
    kicker: "Джизак · Сырдарья · Ташкент",
    title: "Качественные дороги начинаются с вас",
    lead: "Асфальт и товарный бетон, речные и горные инертные, цемент и спецтехника — в одном холдинге, с лабораторным контролем.",
    ctaCalc: "Рассчитать стоимость",
    ctaCall: "Позвонить",
    ctaProducts: "Продукция",
  },
  stats: {
    plants: "асфальтовых завода",
    regions: "области производства",
    lines: "направления продукции",
    lab: "лабораторный контроль",
    capacity: "производство в час",
    staff: "сотрудников",
    fleet: "единиц спецтехники",
  },
  directions: {
    kicker: "Направления",
    title: "Что производит холдинг",
    lead: "Ключевые звенья строительной цепочки — от сырья до дорожного слоя — на собственных мощностях.",
    asphalt: {
      title: "Асфальтобетон",
      text: "Горячая смесь, доставка, укладка и уплотнение. Российский битум, минеральный порошок, лаборатория.",
    },
    concrete: {
      title: "Товарный бетон",
      text: "Смеси до марки M400, плиты и изделия Ultra Beton — под нужный размер.",
    },
    aggregate: {
      title: "Речные и горные материалы",
      text: "Щебень, гравий, строительные пески. Линия New Nerud — карьер и река.",
    },
    logistics: {
      title: "Техника и логистика",
      text: "Цементовозы, самосвалы, укладчики, катки, грейдеры, бульдозеры и другая механика.",
    },
  },
  why: {
    kicker: "Почему мы",
    title: "Качество — от завода до дороги",
    lead: "Ташкент, Сырдарья и Джизак: сырьё, лаборатория и бригада укладки в одной системе.",
    items: [
      {
        title: "Итальянские и немецкие технологии",
        text: "Современные асфальтобетонные узлы, цикл по стандартам.",
      },
      {
        title: "Российский битум",
        text: "Стабильный битум в смеси — слой не трещит, дорога служит дольше.",
      },
      {
        title: "Лабораторный контроль",
        text: "Каждая партия проходит минеральный порошок и лабораторную проверку.",
      },
      {
        title: "Свои бригады и техника",
        text: "Доставка, укладка, уплотнение — люди и механизмы свои.",
      },
    ],
  },
  plants: {
    kicker: "География",
    title: "Производство в трёх областях",
    jizzax: {
      title: "Джизак — основная площадка",
      text: "г. Джизак, промзона A. Ориентир: напротив кондитерской «DEYA», конечная 8-го автобуса.",
    },
    sirdaryo: {
      title: "Филиал в Сырдарье",
      text: "Асфальтовый завод области. Полный цикл: доставка, укладка, уплотнение.",
    },
    toshkent: {
      title: "Филиал в Ташкентской области",
      text: "Качественный асфальт и дорожные работы в Ташкентской области.",
    },
  },
  calc: {
    kicker: "Быстрый расчёт",
    title: "Прикиньте объём заказа",
    lead: "Цены ориентировочные, «от». Точную смету даст специалист после осмотра.",
    asphalt: "Асфальт",
    concrete: "Товарный бетон",
    slab: "Бетонная плита",
    length: "Длина, м",
    width: "Ширина, м",
    thickness: "Толщина, см",
    height: "Толщина, см",
    area: "Площадь",
    volume: "Объём",
    mass: "Масса",
    estimate: "Ориентир по сумме",
    from: "от",
    perTon: "сум / тонна",
    perM3: "сум / м³",
    perM: "сум / м",
    submit: "Оставить заявку",
    note: "Плотность асфальта принята 2,35 т/м³. Итог зависит от плеча, основания и сезона.",
    resultEmpty: "Введите размеры — расчёт появится сам.",
  },
  projects: {
    kicker: "Проекты",
    title: "Дорога — для людей",
    all: "Все",
    road: "Внутрипоселковые",
    city: "Город",
    yard: "Двор",
    viewAll: "Все проекты",
    items: [
      {
        id: "forish",
        tag: "road",
        title: "Фариш, кишлак Сафар ота",
        text: "Внутренние дороги МФЙ UCHMA. Удобное движение для 407 домовладений.",
      },
      {
        id: "rashidov",
        tag: "city",
        title: "Джизак: Рашидов — Нариманов",
        text: "Новая связка двух улиц — городская инфраструктура.",
      },
      {
        id: "baxmal",
        tag: "road",
        title: "Бахмал, МФЙ Маданият",
        text: "Асфальтирование улиц в рамках Open Budget.",
      },
      {
        id: "yard",
        tag: "yard",
        title: "Асфальт во дворе",
        text: "Осмотр, замер, коммерческое предложение и слой, готовый к езде за день.",
      },
    ],
  },
  subs: {
    kicker: "Состав холдинга",
    title: "NTH, Ultra Beton, New Nerud",
    nth: "Головной холдинг — асфальтовые заводы, дороги и парк спецтехники.",
    ultra: "Высокомарочный бетон, плиты и шпалеры для садов. M400, нужный размер.",
    nerud: "Речные и горные инертные: щебень, гравий, строительный песок.",
  },
  cta: {
    title: "Посчитаем вашу дорогу сегодня",
    text: "Специалист осмотрит объект бесплатно. Telegram или звонок — как удобнее.",
    telegram: "Telegram",
    call: "Звонок",
  },
  aboutPage: {
    kicker: "Компания",
    title: "Холдинг, который держит стройку",
    lead: "«Nurli To‘lqin» Holding — производственная группа в Джизаке с филиалами в Ташкентской и Сырдарьинской областях. Мы не только укладываем дорогу — мы сами варим асфальт.",
    storyTitle: "Завод, лаборатория, бригада",
    story:
      "Многие считают асфальт просто покрытием. Для нас это многолетняя инвестиция. Поэтому состав смеси, битум и технология укладки контролируются в одной системе. Горячий асфальт доставляется, укладывается и уплотняется своими людьми и механизмами.",
    valuesTitle: "Принципы",
    values: [
      { title: "Качество", text: "Лаборатория, минеральный порошок, стабильный битум." },
      { title: "Прозрачность", text: "Замер, смета, срок — заранее." },
      { title: "Скорость", text: "Правильно уложенный слой готов к езде за 1 день." },
      { title: "Охват", text: "Областные дороги, улицы махалли, дворы." },
    ],
    factsTitle: "В цифрах",
    facts: [
      { n: "2,5 га", text: "Производственная площадка в Джизаке." },
      { n: "250 т/час", text: "Мощность современного асфальтового завода." },
      { n: "460 тыс. т", text: "Годовая мощность по асфальтобетону." },
      { n: "450+", text: "Сотрудников — общежитие, столовая, спецодежда." },
      { n: "200+", text: "Парк спецтехники, самосвалов и погрузчиков." },
      { n: "6", text: "Камнедробильных предприятий в Шараф Рашидове и Галляарале." },
    ],
  },
  productsPage: {
    kicker: "Продукция",
    title: "То, что выходит с завода",
    lead: "Цены — стартовые по каталогу Prom.uz. Точная смета зависит от объёма, плеча и марки.",
    asphaltTitle: "Готовый асфальтобетон",
    asphaltText:
      "Горячая смесь. Российский битум, минеральный порошок. Доставка, укладка и уплотнение — отдельно или пакетом.",
    asphaltPrice: "от 480 000 сум / т",
    concreteTitle: "Товарный бетон",
    concreteText: "Смесь с доставкой на площадку. Линия Ultra Beton — до марки M400.",
    concretePrice: "от 470 000 сум / м³",
    slabTitle: "Бетонные плиты",
    slabText: "Плиты перекрытий и дорожные. Изготовление под размер.",
    slabPrice: "от 230 000 сум / м",
    cementTitle: "Цемент — тара и навал",
    cementText: "Оптовый цемент, доставка цементовозом. Фасовка и навал.",
    aggregateTitle: "Инертные материалы",
    aggregateText: "Щебень, гравий, песок с реки и карьера. Для основания и бетона.",
    ultraTitle: "Изделия Ultra Beton",
    ultraText:
      "Опоры 10×10 см для виноградников, внутри проволока BP-1400. Бетон M400.",
  },
  servicesPage: {
    kicker: "Услуги",
    title: "Укладка, уплотнение, механика",
    lead: "Мы не только продаём смесь — готовим основание, укладываем и укатываем.",
    processTitle: "Двор и дорога — 4 шага",
    steps: [
      {
        n: "01",
        title: "Осмотр места",
        text: "Специалист смотрит площадь, уклон и существующий слой. Бесплатно.",
      },
      {
        n: "02",
        title: "Замер и расчёт",
        text: "Квадратные метры, грунт, потребность в щебне.",
      },
      {
        n: "03",
        title: "Коммерческое предложение",
        text: "Цена и срок письменно. Всё прозрачно.",
      },
      {
        n: "04",
        title: "Старт работ",
        text: "Чисто, ровно, щебень, горячий асфальт. Слой готов к езде за день.",
      },
    ],
    fleetTitle: "Парк спецтехники",
    fleetLead: "От укладчика до гудронатора — также в аренду под заказ.",
  },
  jobsPage: {
    kicker: "Вакансии",
    title: "В команду",
    lead: "Офис, завод и дорожные бригады. Подробности в канале @nthvacancy.",
    apply: "Откликнуться",
    channel: "Канал вакансий",
    items: [
      {
        id: "secretary",
        title: "Секретарь",
        place: "Головной офис",
        text: "Уверенный ПК, порядок и ответственность. Возраст 30–40. Достойный оклад.",
      },
      {
        id: "paver",
        title: "Оператор укладчика",
        place: "Джизак / Сырдарья",
        text: "Опыт на Vögele или аналоге. Работа в дорожной бригаде.",
      },
      {
        id: "driver",
        title: "Водитель цементовоза / самосвала",
        place: "Логистика",
        text: "Категория CE, опыт промышленных перевозок. Межобластные маршруты.",
      },
      {
        id: "lab",
        title: "Лаборант",
        place: "Асфальтовый завод",
        text: "Пробы смеси, минеральный порошок и битум. Профильное образование плюс.",
      },
      {
        id: "foreman",
        title: "Прораб дорожного строительства",
        place: "Объекты",
        text: "Подготовка основания и укладка, смета и контроль качества.",
      },
    ],
  },
  contactPage: {
    kicker: "Контакты",
    title: "Заявка и консультация",
    lead: "Телефон, Telegram или форма — как удобнее. Отвечаем в рабочие часы.",
    formName: "Имя",
    formPhone: "Телефон",
    formProduct: "Продукт / услуга",
    formMessage: "Комментарий",
    formSend: "Отправить",
    formSent: "Заявка принята. Свяжемся в ближайшее время.",
    formError: "Укажите имя и телефон.",
    addressTitle: "Офис / завод",
    address:
      "г. Джизак, промзона A. Ориентир: напротив «DEYA», конечная 8-го автобуса.",
    phonesTitle: "Телефоны",
    socialsTitle: "Соцсети",
    plantsTitle: "Заводы",
    map: "Открыть на карте",
    productOpts: {
      asphalt: "Асфальт",
      concrete: "Товарный бетон",
      slab: "Бетонная плита",
      cement: "Цемент",
      machinery: "Спецтехника",
      aggregate: "Инертные",
      ultra: "Ultra Beton",
      other: "Другое",
    },
  },
  form: {
    namePh: "Ваше имя",
    phonePh: "+998 ·· ··· ·· ··",
    messagePh: "Площадь, адрес, срок…",
  },
  footer: {
    rights: "Все права защищены.",
    made: "Джизак, Узбекистан",
  },
  notFound: {
    title: "Страница не найдена",
    text: "Этого адреса нет или он перенесён.",
    home: "На главную",
  },
  machinery: {
    paver: "Асфальтоукладчик",
    pneumatic: "Пневмокаток",
    roller95: "Каток",
    roller85: "Каток",
    roller27: "Каток",
    vibro: "Виброкаток",
    grader: "Грейдер",
    trailer: "Трейлер",
    miller: "Фреза",
    bulldozer: "Бульдозер",
    bitumen: "Битумовоз",
    manipulator: "Манипулятор",
    water20: "Поливальная",
    water8: "Поливальная",
    distributor: "Гудронатор",
    cementTruck: "Цементовоз",
    dump: "Самосвал",
  },
  float: {
    call: "Звонок",
    chat: "Чат",
    calc: "Расчёт",
  },
};

const dict = { uz, ru } as const;

type I18nCtx = {
  lang: Lang;
  setLang: (lang: Lang) => void;
  t: (typeof dict)[Lang];
};

const Ctx = createContext<I18nCtx | null>(null);
const STORAGE_KEY = "nth-lang";

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("uz");

  useEffect(() => {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved === "ru" || saved === "uz") setLangState(saved);
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  const setLang = useCallback((next: Lang) => {
    setLangState(next);
    window.localStorage.setItem(STORAGE_KEY, next);
  }, []);

  const value = useMemo(() => ({ lang, setLang, t: dict[lang] }), [lang, setLang]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useI18n() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useI18n outside provider");
  return ctx;
}
