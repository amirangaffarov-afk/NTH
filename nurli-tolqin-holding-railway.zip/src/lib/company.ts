export const COMPANY = {
  name: "Nurli To‘lqin Holding",
  short: "NTH",
  instagram: "https://www.instagram.com/nurli_tulqin_holding/",
  telegram: "https://t.me/nurli_tulqin_holding",
  telegramVacancy: "https://t.me/nthvacancy",
  facebook: "https://www.facebook.com/nurlitulqinholding",
  threads: "https://www.threads.com/@nurli_tulqin_holding",
} as const;

export const PHONES = {
  main: [
    { label: "+998 99 580 11 11", digits: "998995801111" },
    { label: "+998 91 928 77 77", digits: "998919287777" },
  ],
  plants: [
    { label: "+998 95 210 53 53", digits: "998952105353" },
    { label: "+998 91 940 77 77", digits: "998919407777" },
  ],
  machinery: [
    { label: "+998 91 941 77 77", digits: "998919417777" },
    { label: "+998 91 940 77 77", digits: "998919407777" },
  ],
  ultraBeton: [
    { label: "+998 99 506 30 00", digits: "998995063000" },
    { label: "+998 90 490 55 55", digits: "998904905555" },
  ],
  vacancy: [{ label: "+998 99 355 31 31", digits: "998993553131" }],
  yard: [{ label: "+998 95 226 05 50", digits: "998952260550", person: "Ruslan" }],
} as const;

export const PRICES = {
  asphaltPerTon: 480_000,
  concretePerM3: 470_000,
  slabPerM: 230_000,
  asphaltDensity: 2.35,
} as const;

export const PLANTS = [
  {
    id: "jizzax",
    image: "/images/plant-asphalt.jpg",
    map: "https://maps.google.com/?q=Jizzax+A-sanoat+hududi",
  },
  {
    id: "sirdaryo",
    image: "/images/laying-asphalt.jpg",
    map: "https://maps.app.goo.gl/bmbWoccHLHLZjQ476",
  },
  {
    id: "toshkent",
    image: "/images/hero-highway.jpg",
    map: "https://maps.google.com/?q=Toshkent+viloyati+asfalt",
  },
] as const;

export const SOCIALS = [
  { id: "telegram", href: COMPANY.telegram, label: "Telegram" },
  { id: "instagram", href: COMPANY.instagram, label: "Instagram" },
  { id: "facebook", href: COMPANY.facebook, label: "Facebook" },
] as const;

export const MACHINERY = [
  { id: "paver", spec: "Vögele" },
  { id: "pneumatic", spec: "16 t" },
  { id: "roller95", spec: "9,5 t" },
  { id: "roller85", spec: "8,5 t" },
  { id: "roller27", spec: "2,7 t" },
  { id: "vibro", spec: "14 t" },
  { id: "grader", spec: "" },
  { id: "trailer", spec: "12 m" },
  { id: "miller", spec: "1000 / 220 mm" },
  { id: "bulldozer", spec: "Shantui" },
  { id: "bitumen", spec: "28 000 kg" },
  { id: "manipulator", spec: "XCMG" },
  { id: "water20", spec: "20 t" },
  { id: "water8", spec: "8 t" },
  { id: "distributor", spec: "" },
  { id: "cementTruck", spec: "" },
  { id: "dump", spec: "" },
] as const;
