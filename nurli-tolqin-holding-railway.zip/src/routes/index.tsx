import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowDown, Phone } from "lucide-react";
import { QuoteCalculator } from "@/components/quote-calculator";
import { CtaBand, Frame, Kicker, Lead, Section, SectionTitle } from "@/components/section";
import { SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { COMPANY, PHONES, PLANTS } from "@/lib/company";
import { telHref } from "@/lib/format";
import { useI18n } from "src/lib/i18n";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { t } = useI18n();

  return (
    <SiteShell>
      <Hero />

      <section className="border-b border-line bg-surface">
        <div className="mx-auto grid max-w-6xl grid-cols-2 gap-px bg-line sm:grid-cols-4">
          {[
            { n: "3", label: t.stats.plants },
            { n: "250 t", label: t.stats.capacity },
            { n: "450+", label: t.stats.staff },
            { n: "200+", label: t.stats.fleet },
          ].map((item) => (
            <div key={item.label} className="bg-surface px-4 py-8 sm:px-6 sm:py-10">
              <p className="font-display text-3xl uppercase tabular-nums text-fg sm:text-4xl">
                {item.n}
              </p>
              <p className="mt-2 text-sm text-muted">{item.label}</p>
            </div>
          ))}
        </div>
      </section>

      <Section>
        <Kicker>{t.directions.kicker}</Kicker>
        <SectionTitle>{t.directions.title}</SectionTitle>
        <Lead>{t.directions.lead}</Lead>
        <div className="mt-10 grid gap-4 sm:grid-cols-2">
          {(
            [
              {
                key: "asphalt",
                href: "/mahsulotlar",
                image: "/images/laying-asphalt.jpg",
                data: t.directions.asphalt,
              },
              {
                key: "concrete",
                href: "/mahsulotlar",
                image: "/images/concrete-pour.jpg",
                data: t.directions.concrete,
              },
              {
                key: "aggregate",
                href: "/mahsulotlar",
                image: "/images/quarry.jpg",
                data: t.directions.aggregate,
              },
              {
                key: "logistics",
                href: "/xizmatlar",
                image: "/images/fleet.jpg",
                data: t.directions.logistics,
              },
            ] as const
          ).map((card) => (
            <Link
              key={card.key}
              to={card.href}
              className="group relative isolate min-h-72 overflow-hidden rounded-xl border border-line"
            >
              <Frame
                src={card.image}
                alt={card.data.title}
                className="absolute inset-0 transition-transform duration-[var(--motion-slow)] ease-[var(--ease-out)] group-hover:scale-[1.04]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-bg/10" />
              <div className="relative flex h-full min-h-72 flex-col justify-end p-5 sm:p-7">
                <h3 className="font-display text-2xl uppercase">{card.data.title}</h3>
                <p className="mt-2 max-w-md text-sm leading-relaxed text-muted">{card.data.text}</p>
              </div>
            </Link>
          ))}
        </div>
      </Section>

      <Section className="bg-surface">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <div className="overflow-hidden rounded-xl border border-line">
            <div className="aspect-16/10">
              <Frame src="/images/lab.jpg" alt={t.why.title} />
            </div>
          </div>
          <div>
            <Kicker>{t.why.kicker}</Kicker>
            <SectionTitle>{t.why.title}</SectionTitle>
            <Lead>{t.why.lead}</Lead>
            <ul className="mt-8 grid gap-5 sm:grid-cols-2">
              {t.why.items.map((item) => (
                <li key={item.title} className="border-t border-line pt-4">
                  <h3 className="font-display text-lg uppercase">{item.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{item.text}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Section>

      <Section>
        <Kicker>{t.plants.kicker}</Kicker>
        <SectionTitle>{t.plants.title}</SectionTitle>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {PLANTS.map((plant) => {
            const copy = t.plants[plant.id];
            return (
              <article
                key={plant.id}
                className="overflow-hidden rounded-xl border border-line bg-surface"
              >
                <div className="aspect-16/10">
                  <Frame src={plant.image} alt={copy.title} />
                </div>
                <div className="p-5">
                  <h3 className="font-display text-xl uppercase">{copy.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{copy.text}</p>
                </div>
              </article>
            );
          })}
        </div>
      </Section>

      <Section id="hisob" className="bg-surface">
        <div className="grid items-start gap-10 lg:grid-cols-2">
          <div>
            <Kicker>{t.calc.kicker}</Kicker>
            <SectionTitle>{t.calc.title}</SectionTitle>
            <Lead>{t.calc.lead}</Lead>
          </div>
          <QuoteCalculator />
        </div>
      </Section>

      <Section>
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <Kicker>{t.projects.kicker}</Kicker>
            <SectionTitle>{t.projects.title}</SectionTitle>
          </div>
          <Button asChild variant="outline">
            <Link to="/loyihalar">{t.projects.viewAll}</Link>
          </Button>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-2">
          {t.projects.items.map((item, i) => (
            <article
              key={item.id}
              className="overflow-hidden rounded-xl border border-line bg-surface"
            >
              <div className="aspect-16/10">
                <Frame
                  src={
                    [
                      "/images/village-road.jpg",
                      "/images/hero-highway.jpg",
                      "/images/laying-asphalt.jpg",
                      "/images/night-paving.jpg",
                    ][i] ?? "/images/village-road.jpg"
                  }
                  alt={item.title}
                />
              </div>
              <div className="p-5">
                <p className="text-xs uppercase tracking-kicker text-subtle">
                  {t.projects[item.tag as "road" | "city" | "yard"]}
                </p>
                <h3 className="mt-2 font-display text-xl uppercase">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{item.text}</p>
              </div>
            </article>
          ))}
        </div>
      </Section>

      <Section className="bg-surface">
        <Kicker>{t.subs.kicker}</Kicker>
        <SectionTitle>{t.subs.title}</SectionTitle>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {(
            [
              { brand: "NTH", text: t.subs.nth, image: "/images/plant-asphalt.jpg" },
              { brand: "Ultra Beton", text: t.subs.ultra, image: "/images/ultra-posts.jpg" },
              { brand: "New Nerud", text: t.subs.nerud, image: "/images/quarry.jpg" },
            ] as const
          ).map((sub) => (
            <article
              key={sub.brand}
              className="overflow-hidden rounded-xl border border-line bg-bg"
            >
              <div className="aspect-16/10">
                <Frame src={sub.image} alt={sub.brand} />
              </div>
              <div className="p-5">
                <h3 className="font-display text-xl uppercase tracking-wide">{sub.brand}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{sub.text}</p>
              </div>
            </article>
          ))}
        </div>
      </Section>

      <CtaBand />
    </SiteShell>
  );
}

function Hero() {
  const { t } = useI18n();
  return (
    <section className="relative isolate min-h-[100dvh] overflow-hidden">
      <Frame
        src="/images/hero-highway.jpg"
        alt={t.hero.title}
        priority
        className="absolute inset-0"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/70 to-bg/25" />
      <div className="relative mx-auto flex min-h-[100dvh] max-w-6xl flex-col justify-end px-4 pb-28 pt-28 sm:px-6 sm:pb-20">
        <p className="text-xs font-semibold uppercase tracking-kicker text-primary">
          {t.hero.kicker}
        </p>
        <h1 className="mt-4 max-w-4xl font-display text-display uppercase">{t.hero.title}</h1>
        <p className="mt-5 max-w-xl text-base leading-relaxed text-muted sm:text-lg">{t.hero.lead}</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Button asChild size="lg">
            <Link to="/" hash="hisob">
              {t.hero.ctaCalc}
            </Link>
          </Button>
          <Button asChild size="lg" variant="solid">
            <a href={telHref(PHONES.main[0].digits)}>
              <Phone />
              {t.hero.ctaCall}
            </a>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link to="/mahsulotlar">{t.hero.ctaProducts}</Link>
          </Button>
        </div>
        <a
          href="#hisob"
          className="mt-12 inline-flex w-fit items-center gap-2 text-xs uppercase tracking-kicker text-subtle"
        >
          <ArrowDown className="size-4" />
          {COMPANY.short}
        </a>
      </div>
    </section>
  );
}
