import { createFileRoute } from "@tanstack/react-router";
import { CtaBand, Frame, Kicker, Lead, Section, SectionTitle } from "@/components/section";
import { PageHero, SiteShell } from "@/components/site-shell";
import { MACHINERY, PHONES } from "@/lib/company";
import { telHref } from "@/lib/format";
import { useI18n } from "src/lib/i18n";

export const Route = createFileRoute("/xizmatlar")({ component: ServicesPage });

function ServicesPage() {
  const { t } = useI18n();
  const p = t.servicesPage;

  return (
    <SiteShell>
      <PageHero kicker={p.kicker} title={p.title} lead={p.lead} />

      <Section>
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <div className="overflow-hidden rounded-xl border border-line">
            <div className="aspect-16/10">
              <Frame src="/images/night-paving.jpg" alt={p.processTitle} />
            </div>
          </div>
          <div>
            <Kicker>{p.kicker}</Kicker>
            <SectionTitle>{p.processTitle}</SectionTitle>
            <ol className="mt-8 grid gap-6">
              {p.steps.map((step) => (
                <li key={step.n} className="grid grid-cols-[auto_1fr] gap-4 border-t border-line pt-4">
                  <span className="font-display text-2xl tabular-nums text-primary">{step.n}</span>
                  <div>
                    <h3 className="font-display text-lg uppercase">{step.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-muted">{step.text}</p>
                  </div>
                </li>
              ))}
            </ol>
            <p className="mt-6 text-sm text-muted">
              {PHONES.yard[0].person}:{" "}
              <a className="text-fg hover:text-primary" href={telHref(PHONES.yard[0].digits)}>
                {PHONES.yard[0].label}
              </a>
            </p>
          </div>
        </div>
      </Section>

      <Section className="bg-surface">
        <div className="grid items-start gap-10 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <Kicker>{p.fleetTitle}</Kicker>
            <SectionTitle>{p.fleetTitle}</SectionTitle>
            <Lead>{p.fleetLead}</Lead>
            <ul className="mt-8 grid gap-2 sm:grid-cols-2">
              {MACHINERY.map((m) => (
                <li
                  key={m.id}
                  className="flex items-baseline justify-between gap-3 rounded-md border border-line bg-bg px-4 py-3"
                >
                  <span className="text-sm text-fg">{t.machinery[m.id]}</span>
                  {m.spec ? (
                    <span className="text-xs tabular-nums text-subtle">{m.spec}</span>
                  ) : null}
                </li>
              ))}
            </ul>
          </div>
          <div className="overflow-hidden rounded-xl border border-line">
            <div className="aspect-4/5">
              <Frame src="/images/fleet.jpg" alt={p.fleetTitle} />
            </div>
          </div>
        </div>
      </Section>

      <CtaBand />
    </SiteShell>
  );
}
