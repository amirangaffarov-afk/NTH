import { createFileRoute } from "@tanstack/react-router";
import { ContactForm } from "@/components/contact-form";
import { CtaBand, Section } from "@/components/section";
import { PageHero, SiteShell } from "@/components/site-shell";
import { COMPANY, PHONES, PLANTS, SOCIALS } from "@/lib/company";
import { telHref } from "@/lib/format";
import { useI18n } from "src/lib/i18n";

const PRODUCT_KEYS = [
  "asphalt",
  "concrete",
  "slab",
  "cement",
  "machinery",
  "aggregate",
  "ultra",
  "other",
] as const;

function parseProduct(value: unknown): string {
  return typeof value === "string" && (PRODUCT_KEYS as readonly string[]).includes(value)
    ? value
    : "asphalt";
}

export const Route = createFileRoute("/aloqa")({
  validateSearch: (search: Record<string, unknown>): { product?: string } => {
    const product = parseProduct(search.product);
    if (typeof search.product !== "string") return {};
    return { product };
  },
  component: ContactPage,
});

function ContactPage() {
  const { t } = useI18n();
  const { product } = Route.useSearch();
  const p = t.contactPage;

  return (
    <SiteShell>
      <PageHero kicker={p.kicker} title={p.title} lead={p.lead} />
      <Section>
        <div className="grid gap-10 lg:grid-cols-2">
          <ContactForm initialProduct={product} />
          <div className="grid gap-8">
            <div>
              <h2 className="font-display text-xl uppercase">{p.addressTitle}</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted">{p.address}</p>
            </div>
            <div>
              <h2 className="font-display text-xl uppercase">{p.phonesTitle}</h2>
              <ul className="mt-3 space-y-2">
                {PHONES.main.map((phone) => (
                  <li key={phone.digits}>
                    <a
                      href={telHref(phone.digits)}
                      className="font-display text-2xl uppercase tabular-nums text-fg hover:text-primary"
                    >
                      {phone.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h2 className="font-display text-xl uppercase">{p.plantsTitle}</h2>
              <ul className="mt-3 space-y-4">
                {PLANTS.map((plant) => (
                  <li key={plant.id}>
                    <p className="text-sm font-medium text-fg">{t.plants[plant.id].title}</p>
                    <a
                      href={plant.map}
                      target="_blank"
                      rel="noreferrer"
                      className="text-sm text-muted hover:text-fg"
                    >
                      {p.map}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h2 className="font-display text-xl uppercase">{p.socialsTitle}</h2>
              <ul className="mt-3 flex flex-wrap gap-3">
                {SOCIALS.map((s) => (
                  <li key={s.id}>
                    <a
                      href={s.href}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex h-11 items-center rounded-md border border-line px-4 text-sm text-fg hover:bg-surface-2"
                    >
                      {s.label}
                    </a>
                  </li>
                ))}
                <li>
                  <a
                    href={COMPANY.telegramVacancy}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex h-11 items-center rounded-md border border-line px-4 text-sm text-fg hover:bg-surface-2"
                  >
                    {t.jobsPage.channel}
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </Section>
      <CtaBand />
    </SiteShell>
  );
}
