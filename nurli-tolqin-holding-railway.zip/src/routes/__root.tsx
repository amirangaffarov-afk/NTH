import { createRootRoute, HeadContent, Link, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { I18nProvider, useI18n } from "src/lib/i18n";
import { Toaster } from "sonner";
import appCss from "../styles.css?url";

const APP_NAME = "Nurli To‘lqin Holding";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: APP_NAME },
      { name: "theme-color", content: "#07090d" },
      {
        name: "description",
        content:
          "Asfalt, tayyor beton, inert materiallar va maxsus texnika. Jizzax, Sirdaryo, Toshkent.",
      },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=Oswald:wght@400;500;600;700&display=swap",
      },
    ],
  }),
  component: RootComponent,
  notFoundComponent: NotFound,
});

function RootComponent() {
  return (
    <html lang="uz" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <I18nProvider>
            <Outlet />
            <Toaster
              theme="dark"
              position="top-center"
              toastOptions={{
                classNames: {
                  toast: "border-line bg-surface text-fg",
                },
              }}
            />
          </I18nProvider>
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}

function NotFound() {
  const { t } = useI18n();
  return (
    <SiteShell>
      <div className="mx-auto flex min-h-[70dvh] max-w-6xl flex-col justify-center px-4 py-24 sm:px-6">
        <p className="text-xs font-semibold uppercase tracking-kicker text-primary">404</p>
        <h1 className="mt-3 font-display text-section uppercase">{t.notFound.title}</h1>
        <p className="mt-4 max-w-md text-muted">{t.notFound.text}</p>
        <Button asChild className="mt-8 w-fit">
          <Link to="/">{t.notFound.home}</Link>
        </Button>
      </div>
    </SiteShell>
  );
}
