import { createFileRoute } from "@tanstack/react-router";
import { CtaBand, Section } from "@/components/section";
import { PageHero, SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { COMPANY, PHONES } from "@/lib/company";
import { telHref } from "@/lib/format";
import { useI18n } from "src/lib/i18n";

export const Route = createFileRoute("/vakansiyalar")({ component: JobsPage });

function JobsPage() {
  const { t } = useI18n();
  const p = t.jobsPage;

  return (
    <SiteShell>
      <PageHero kicker={p.kicker} title={p.title} lead={p.lead} />
      <Section>
        <div className="mb-8 flex flex-wrap gap-3">
          <Button asChild>
            <a href={COMPANY.telegramVacancy} target="_blank" rel="noreferrer">
              {p.channel}
            </a>
          </Button>
          <Button asChild variant="outline">
            <a href={telHref(PHONES.vacancy[0].digits)}>{PHONES.vacancy[0].label}</a>
          </Button>
        </div>
        <div className="grid gap-4">
          {p.items.map((job) => (
            <article
              key={job.id}
              className="flex flex-col gap-4 rounded-xl border border-line bg-surface p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6"
            >
              <div className="max-w-2xl">
                <p className="text-xs uppercase tracking-kicker text-subtle">{job.place}</p>
                <h2 className="mt-1 font-display text-2xl uppercase">{job.title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-muted">{job.text}</p>
              </div>
              <Button asChild variant="outline" className="shrink-0">
                <a href={COMPANY.telegramVacancy} target="_blank" rel="noreferrer">
                  {p.apply}
                </a>
              </Button>
            </article>
          ))}
        </div>
      </Section>
      <CtaBand />
    </SiteShell>
  );
}
