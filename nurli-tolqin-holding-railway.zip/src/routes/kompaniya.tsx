import { createFileRoute } from "@tanstack/react-router";
import { CtaBand, Frame, Kicker, Lead, Section, SectionTitle } from "@/components/section";
import { PageHero, SiteShell } from "@/components/site-shell";
import { useI18n } from "src/lib/i18n";

export const Route = createFileRoute("/kompaniya")({ component: AboutPage });

function AboutPage() {
  const { t } = useI18n();
  const p = t.aboutPage;

  return (
    <SiteShell>
      <PageHero kicker={p.kicker} title={p.title} lead={p.lead} />

      <Section>
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <div className="overflow-hidden rounded-xl border border-line">
            <div className="aspect-4/3">
              <Frame src="/images/plant-asphalt.jpg" alt={p.storyTitle} />
            </div>
          </div>
          <div>
            <Kicker>{p.kicker}</Kicker>
            <SectionTitle>{p.storyTitle}</SectionTitle>
            <Lead>{p.story}</Lead>
          </div>
        </div>
      </Section>

      <Section className="bg-surface">
        <Kicker>{p.valuesTitle}</Kicker>
        <SectionTitle>{p.valuesTitle}</SectionTitle>
        <div className="mt-10 grid gap-4 sm:grid-cols-2">
          {p.values.map((item) => (
            <article key={item.title} className="rounded-xl border border-line bg-bg p-6">
              <h3 className="font-display text-xl uppercase">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{item.text}</p>
            </article>
          ))}
        </div>
      </Section>

      <Section>
        <Kicker>{p.factsTitle}</Kicker>
        <SectionTitle>{p.factsTitle}</SectionTitle>
        <div className="mt-10 grid gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
          {p.facts.map((fact) => (
            <article key={fact.n} className="bg-surface p-6 sm:p-8">
              <p className="font-display text-3xl uppercase tabular-nums text-primary">{fact.n}</p>
              <p className="mt-3 text-sm leading-relaxed text-muted">{fact.text}</p>
            </article>
          ))}
        </div>
      </Section>

      <CtaBand />
    </SiteShell>
  );
}
