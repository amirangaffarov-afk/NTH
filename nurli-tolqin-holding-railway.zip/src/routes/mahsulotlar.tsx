import { createFileRoute, Link } from "@tanstack/react-router";
import { CtaBand, Frame, Section } from "@/components/section";
import { PageHero, SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { useI18n } from "src/lib/i18n";

export const Route = createFileRoute("/mahsulotlar")({ component: ProductsPage });

function ProductsPage() {
  const { t } = useI18n();
  const p = t.productsPage;

  const items = [
    {
      id: "asphalt",
      title: p.asphaltTitle,
      text: p.asphaltText,
      price: p.asphaltPrice,
      image: "/images/laying-asphalt.jpg",
    },
    {
      id: "concrete",
      title: p.concreteTitle,
      text: p.concreteText,
      price: p.concretePrice,
      image: "/images/concrete-pour.jpg",
    },
    {
      id: "slab",
      title: p.slabTitle,
      text: p.slabText,
      price: p.slabPrice,
      image: "/images/slabs.jpg",
    },
    {
      id: "cement",
      title: p.cementTitle,
      text: p.cementText,
      image: "/images/cement.jpg",
    },
    {
      id: "aggregate",
      title: p.aggregateTitle,
      text: p.aggregateText,
      image: "/images/quarry.jpg",
    },
    {
      id: "ultra",
      title: p.ultraTitle,
      text: p.ultraText,
      image: "/images/ultra-posts.jpg",
    },
  ] as const;

  return (
    <SiteShell>
      <PageHero kicker={p.kicker} title={p.title} lead={p.lead} />
      <Section>
        <div className="grid gap-4 md:grid-cols-2">
          {items.map((item) => (
            <article
              key={item.id}
              className="overflow-hidden rounded-xl border border-line bg-surface"
            >
              <div className="aspect-16/10">
                <Frame src={item.image} alt={item.title} />
              </div>
              <div className="p-5 sm:p-6">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <h2 className="font-display text-2xl uppercase">{item.title}</h2>
                  {"price" in item && item.price ? (
                    <span className="rounded-md bg-surface-2 px-3 py-1 text-xs font-medium text-fg">
                      {item.price}
                    </span>
                  ) : null}
                </div>
                <p className="mt-3 text-sm leading-relaxed text-muted">{item.text}</p>
                <Button asChild variant="outline" className="mt-5">
                  <Link to="/aloqa" search={{ product: item.id }}>
                    {t.calc.submit}
                  </Link>
                </Button>
              </div>
            </article>
          ))}
        </div>
      </Section>
      <CtaBand />
    </SiteShell>
  );
}
