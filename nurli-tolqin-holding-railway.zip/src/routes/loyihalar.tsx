import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { CtaBand, Frame, Section } from "@/components/section";
import { PageHero, SiteShell } from "@/components/site-shell";
import { useI18n } from "src/lib/i18n";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/loyihalar")({ component: ProjectsPage });

const IMAGES = [
  "/images/village-road.jpg",
  "/images/hero-highway.jpg",
  "/images/laying-asphalt.jpg",
  "/images/night-paving.jpg",
] as const;

function ProjectsPage() {
  const { t } = useI18n();
  const [tag, setTag] = useState<"all" | "road" | "city" | "yard">("all");
  const filters = [
    { id: "all" as const, label: t.projects.all },
    { id: "road" as const, label: t.projects.road },
    { id: "city" as const, label: t.projects.city },
    { id: "yard" as const, label: t.projects.yard },
  ];
  const items = t.projects.items.filter((item) => tag === "all" || item.tag === tag);

  return (
    <SiteShell>
      <PageHero kicker={t.projects.kicker} title={t.projects.title} lead={t.hero.lead} />
      <Section>
        <div className="flex flex-wrap gap-2">
          {filters.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setTag(f.id)}
              className={cn(
                "h-11 rounded-md px-4 text-sm font-medium",
                tag === f.id ? "bg-primary text-primary-fg" : "bg-surface-2 text-muted",
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          {items.map((item) => {
            const index = t.projects.items.findIndex((x) => x.id === item.id);
            return (
              <article
                key={item.id}
                className="overflow-hidden rounded-xl border border-line bg-surface"
              >
                <div className="aspect-16/10">
                  <Frame src={IMAGES[index] ?? IMAGES[0]} alt={item.title} />
                </div>
                <div className="p-5">
                  <p className="text-xs uppercase tracking-kicker text-subtle">
                    {t.projects[item.tag as "road" | "city" | "yard"]}
                  </p>
                  <h2 className="mt-2 font-display text-2xl uppercase">{item.title}</h2>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{item.text}</p>
                </div>
              </article>
            );
          })}
        </div>
      </Section>
      <CtaBand />
    </SiteShell>
  );
}
